<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800,800italic,300" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
<link href="<?php echo($g_webRoot);?>css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo($g_webRoot);?>css/util.carousel.css" />
<link rel="stylesheet" href="<?php echo($g_webRoot);?>css/util.carousel.skins.css" />
<link href="<?php echo($g_webRoot);?>css/font-awesome.min.css" rel="stylesheet">
<link href="<?php echo($g_webRoot);?>css/easy-responsive-tabs.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo($g_webRoot);?>css/component.css" />
<link rel="stylesheet" type="text/css" href="<?php echo($g_webRoot);?>css/menumaker.css">
<link href="<?php echo($g_webRoot);?>css/style.css" rel="stylesheet">
<link href="<?php echo($g_webRoot);?>css/custom.css" rel="stylesheet">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

