<?php
require_once($g_docRoot . "classes/generic-table.php");
class MealDeal extends GenericTable {

	var $mTable = "j_mealdeal";


}
?>
