<?php
require_once($g_docRoot . "classes/generic-table.php");
class Settings extends GenericTable {

	var $mTable = "j_settings";

}
?>
