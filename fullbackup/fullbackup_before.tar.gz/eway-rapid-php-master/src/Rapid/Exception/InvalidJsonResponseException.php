<?php

namespace Eway\Rapid\Exception;

use RuntimeException;

/**
 * Class InvalidJsonResponseException.
 */
class InvalidJsonResponseException extends RuntimeException
{
}
