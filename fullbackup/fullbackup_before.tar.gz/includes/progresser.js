function showLoader() {
	document.getElementById("loader").style.display='';
}

function hideLoader() {
	document.getElementById("loader").style.display='none';
}


