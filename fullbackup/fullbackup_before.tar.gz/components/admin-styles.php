 <!-- Bootstrap Core CSS -->
    <link href="<?php echo($g_webRoot);?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo($g_webRoot);?>vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo($g_webRoot);?>dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo($g_webRoot);?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

<link href="<?php echo($g_webRoot);?>includes/progresser.css" rel="stylesheet">
<link href="<?php echo($g_webRoot);?>css/admin.css" rel="stylesheet">

<!--[if lt IE 9]>
<script src="<?php echo($g_webRoot);?>js/html5shiv.js"></script>
<script src="<?php echo($g_webRoot);?>js/respond.min.js"></script>
<![endif]-->
