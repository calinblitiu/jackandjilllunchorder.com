    <footer>
    		<div class="container">
            		<div class="row">
                 			<div class="col-lg-3 resize">
                            		   <div class="fotr_links">
                                            <h4>Site Links</h4>
                                            <ul>
                                                    <li><a href="<?php echo($g_webRoot);?>"> Home</a></li>
                                                    <li><a href="<?php echo($g_webRoot);?>about-us">About Us</a></li>
                                                   <li><a href="<?php echo($g_webRoot);?>privacy-policy">Privacy Policy</a></li>
												       <li><a href="<?php echo($g_webRoot);?>delivery-policy">Delivery Policy</a></li>
													   <li><a href="<?php echo($g_webRoot);?>refund-policy">Refund Policy</a></li>


                                                    <li><a href="<?php echo($g_webRoot);?>contact">Contact Us</a></li>              
                                                </ul>                    
                        				</div><!--fotr_links-->
                            </div><!--col-lg-3-->
                            
                            <div class="col-lg-3 resize">
                            		   <div class="fotr_links">
                                            <h4>Order Pages</h4>
                                            <ul>
                                                    <li><a href="<?php echo($g_webRoot);?>sign-in">Signup/Login</a></li>
                                                    <li><a href="<?php echo($g_webRoot);?>products-list">Menu</a></li>
                                                    <li><a href="<?php echo($g_webRoot);?>subscription-plan">Subscription Ordering</a></li>                  
                                                </ul>                    
                        				</div><!--fotr_links-->
                            </div><!--col-lg-3-->
                            
                            
                            <div class="col-lg-3 resize">
                            		   <div class="fotr_links">
                                            <h4>Customer Info</h4>
                                            <ul>
                                                  <li><a href="<?php echo($g_webRoot);?>sign-in">Signup/Login</a></li>
                                                    <li><a href="<?php echo($g_webRoot);?>dashboard">My Account</a></li>
                                            	</ul>                    
                        				</div><!--fotr_links-->
                            </div><!--col-lg-3-->
                            
                            <div class="col-lg-3 resize">
                            		   <div class="fotr_links">
                                            <h4>Newsletter</h4>
                                          <div class="news_letrform">
                                          		<form>
                                                		<input type="text" placeholder="Enter Your Email ID">
                                                        <button type="submit">subscribe</button>
                                                </form>
                                          </div>    
                        				</div><!--fotr_links-->
                            </div><!--col-lg-3-->
                            
                            <div class="col-lg-3 resize">
                            		   <div class="fotr_links">
                                            <h4>Contact us</h4>
                                            	<div class="fotr_eml"><a href="mailto:orders@jackandjill.com.au">orders@jackandjill.com.au</a></div>
                                            <div class="social_links">
                                            		<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                                    <a href="#"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                                                    <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                                    <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                                    <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                                            </div>      
                                            <div class="copy_rights">@ 2017. All rights reserved. 
<a href="<?php echo($g_webRoot);?>privacy-policy">Privacy Policy</a> &nbsp; <a href="<?php echo($g_webRoot);?>app">Download App</a> &nbsp;<a href=#>Warranty	</a>						 </div>       
                        				</div><!--fotr_links-->
                            </div><!--col-lg-3-->
            		</div>
            </div>
    
    </footer>

