	<!-- show errors POPUP -->
	 <div class="modal bounceIn animated in" id="errors-popup" tabindex="-1" role="dialog" aria-labelledby="catalogLabel" aria-hidden="true">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-header bg-danger">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			<div class="modal-title" id="errorLabel">Errors</div>
		  </div>
		  <div class="modal-body">
				<div class="col-sm-12 fg-black" id="errorContent">
				</div>
			<div class="clearfix"></div>
			<div class="col-sm-2"></div>
			<div class="clearfix"></div>

		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-sm" data-dismiss="modal">Close</button>
		  </div>
		</div><!-- modal-content -->
	  </div><!-- modal-dialog -->
	</div>


