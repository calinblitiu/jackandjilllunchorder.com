<?php phpinfo();

?>